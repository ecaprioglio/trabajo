/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.predictor.main;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SistemaDeAdmision implements ProcesoFinalAdmision { 
    private final LectorDatosSimulados lector;
    private final EntradaUsuario entrada;
    private final CalculadoraPuntajes calculadora;
    private final ReporteFinal reporte;
    private final Map<String, List<Postulante>> datosSimulados;

    public SistemaDeAdmision() {
        this.lector = new LectorDatosSimulados();
        this.entrada = new EntradaUsuario();
        this.calculadora = new CalculadoraPuntajes();
        this.reporte = new ReporteFinal();
        this.datosSimulados = new HashMap<>();
    }

    public void iniciar() {
        lector.leerArchivo(datosSimulados);
        Postulante usuario = entrada.obtenerDatosPostulante();
        Carrera carreraElegida = entrada.elegirCarrera();
        
        aplicarBonoRanking(usuario);
        
        List<Postulante> simuladosParaCarrera = datosSimulados.get(carreraElegida.getNombre());
        
        double puntajeCorte = calcularPuntajeCorte(simuladosParaCarrera, carreraElegida);
        double puntajeUsuario = carreraElegida.calcularPonderado(usuario.getPuntajes());
        
        String resultado = (puntajeUsuario >= puntajeCorte) ? "ACEPTADO" : "RECHAZADO";
        
        mostrarReporte(usuario, carreraElegida, puntajeUsuario, puntajeCorte, resultado);
    }


    @Override
    public void aplicarBonoRanking(Postulante usuario) {
        calculadora.aplicarBonoRanking(usuario);
    }

    @Override
    public double calcularPuntajeCorte(List<Postulante> simulados, Carrera carrera) {
        return calculadora.calcularPuntajeCorte(simulados, carrera);
    }

    @Override
    public void mostrarReporte(Postulante usuario, Carrera carrera, double puntajeUsuario, double puntajeCorte, String resultado) {
        reporte.mostrar(usuario, carrera, puntajeUsuario, puntajeCorte, resultado);
    }
}
