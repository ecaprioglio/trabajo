/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.predictor.main;

public class PuntajeNEM extends Puntaje {
    private final int nota;
    
    public PuntajeNEM(int valor,int nota) { 
        super(valor);
        this.nota = nota;
    }
}
