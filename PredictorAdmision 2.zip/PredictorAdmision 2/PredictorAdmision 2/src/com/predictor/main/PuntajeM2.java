/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.predictor.main;

public class PuntajeM2 extends Puntaje {
    private final int difm1; // diferencia de punatje con m1
    public PuntajeM2(int valor, int difm1 ) { 
        super(valor);
        this.difm1 = difm1;
        
    }
}
