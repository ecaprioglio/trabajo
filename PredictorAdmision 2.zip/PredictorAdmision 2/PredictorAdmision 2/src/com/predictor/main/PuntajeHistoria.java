/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.predictor.main;

public class PuntajeHistoria extends Puntaje {
    private final String areaDeFortaleza;

    public PuntajeHistoria(int valor, String areaDeFortaleza) {
        super(valor);
        this.areaDeFortaleza = areaDeFortaleza;
    }

    public String getAreaDeFortaleza() {
        return areaDeFortaleza;
    }
}