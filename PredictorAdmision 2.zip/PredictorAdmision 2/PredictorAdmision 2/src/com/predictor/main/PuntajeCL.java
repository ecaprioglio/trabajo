/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.predictor.main;

public class PuntajeCL extends Puntaje {
    private final int textosleidos;
    
    public PuntajeCL(int valor, int textosleidos) {
        super(valor); 
        this.textosleidos = textosleidos;
    }
}
