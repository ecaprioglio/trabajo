/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.predictor.main;

import java.util.List;

public interface ProcesoFinalAdmision {

    /**
     * Aplica un bono al puntaje de Ranking si el colegio del postulante está en la lista.
     * @param usuario El postulante al que se le aplicará el bono.
     */
    void aplicarBonoRanking(Postulante usuario);

    /**
     * Calcula el puntaje de corte dinámico para una carrera basándose en los postulantes simulados.
     * @param simulados La lista de postulantes de la simulación.
     * @param carrera La carrera para la cual se calcula el corte.
     * @return El puntaje de corte.
     */
    double calcularPuntajeCorte(List<Postulante> simulados, Carrera carrera);

    /**
     * Muestra el resumen final de la postulación al usuario.
     * @param usuario El postulante.
     * @param carrera La carrera elegida.
     * @param puntajeUsuario El puntaje ponderado final del usuario.
     * @param puntajeCorte El puntaje de corte calculado.
     * @param resultado El veredicto final ("ACEPTADO" o "RECHAZADO").
     */
    void mostrarReporte(Postulante usuario, Carrera carrera, double puntajeUsuario, double puntajeCorte, String resultado);
}
